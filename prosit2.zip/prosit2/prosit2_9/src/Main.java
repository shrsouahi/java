// Classe Animal
class Animal {
    String family;
    String name;
    int age;
    boolean isMammal;


    public Animal(String family, String name, int age, boolean isMammal) {
        this.family = family;
        this.name = name;
        this.age = age;
        this.isMammal = isMammal;
    }


    public void displayAnimalInfo() {
        System.out.println("Animal Name: " + name);
        System.out.println("Family: " + family);
        System.out.println("Age: " + age);
        System.out.println("Is Mammal: " + (isMammal ? "Yes" : "No"));
    }
}


class Zoo {
    Animal[] animals;
    String name;
    String city;
    int nbrCages;
    int currentAnimalCount;


    public Zoo(String name, String city, int nbrCages) {
        this.name = name;
        this.city = city;
        this.nbrCages = nbrCages;
        this.animals = new Animal[25]; // Le zoo peut contenir un maximum de 25 animaux
        this.currentAnimalCount = 0;
    }

    // Méthode pour ajouter un animal au zoo
    public void addAnimal(Animal animal) {
        if (currentAnimalCount < animals.length) {
            animals[currentAnimalCount] = animal;
            currentAnimalCount++;
            System.out.println(animal.name + " a été ajouté au zoo.");
        } else {
            System.out.println("Le zoo est plein. Impossible d'ajouter plus d'animaux.");
        }
    }

    // Méthode pour afficher les informations du zoo
    public void displayZooInfo() {
        System.out.println("Zoo Name: " + name);
        System.out.println("City: " + city);
        System.out.println("Number of Cages: " + nbrCages);
        System.out.println("Animals in the Zoo:");
        for (int i = 0; i < currentAnimalCount; i++) {
            animals[i].displayAnimalInfo();
            System.out.println("-----------------");
        }
    }
}

// Classe principale
public class Main {
    public static void main(String[] args) {
        // Créer des objets Animal avec le constructeur paramétré
        Animal lion = new Animal("Felidae", "Lion", 5, true);
        Animal tiger = new Animal("Felidae", "Tiger", 3, true);
        Animal elephant = new Animal("Elephantidae", "Elephant", 10, true);
        Animal crocodile = new Animal("Crocodylidae", "Crocodile", 7, false);
        Animal giraffe = new Animal("Giraffidae", "Giraffe", 4, true);


        Zoo myZoo = new Zoo("Safari Zoo", "Paris", 10);


        myZoo.addAnimal(lion);
        myZoo.addAnimal(tiger);
        myZoo.addAnimal(elephant);
        myZoo.addAnimal(crocodile);
        myZoo.addAnimal(giraffe);


        myZoo.displayZooInfo();
    }
}
