// Classe Animal
class Animal {
    String family;
    String name;
    int age;
    boolean isMammal;


    public Animal(String family, String name, int age, boolean isMammal) {
        this.family = family;
        this.name = name;
        this.age = age;
        this.isMammal = isMammal;
    }


    public void displayAnimalInfo() {
        System.out.println("Animal Name: " + name);
        System.out.println("Family: " + family);
        System.out.println("Age: " + age);
        System.out.println("Is Mammal: " + (isMammal ? "Yes" : "No"));
    }
}


class Zoo {
    Animal[] animals;
    String name;
    String city;
    int nbrCages;
    int currentAnimalCount;

    // Constructeur pour initialiser les attributs
    public Zoo(String name, String city, int nbrCages) {
        this.name = name;
        this.city = city;
        this.nbrCages = nbrCages;
        this.animals = new Animal[25]; // Zoo peut contenir un maximum de 25 animaux
        this.currentAnimalCount = 0;
    }

    // Méthode pour ajouter un animal au zoo
    public void addAnimal(Animal animal) {
        if (currentAnimalCount < animals.length) {
            animals[currentAnimalCount] = animal;
            currentAnimalCount++;
            System.out.println(animal.name + " a été ajouté au zoo.");
        } else {
            System.out.println("Le zoo est plein. Impossible d'ajouter plus d'animaux.");
        }
    }


    public void displayZooInfo() {
        System.out.println("Zoo Name: " + name);
        System.out.println("City: " + city);
        System.out.println("Number of Cages: " + nbrCages);
        System.out.println("Animals in the Zoo:");
        for (int i = 0; i < currentAnimalCount; i++) {
            animals[i].displayAnimalInfo();
            System.out.println("-----------------");
        }
    }
}
public class Main {
    public static void main(String[] args) {
        // Créer un objet Animal
        Animal lion = new Animal("Felidae", "Lion", 5, true);

        // Créer un objet Zoo
        Zoo myZoo = new Zoo("Safari Zoo", "Paris", 10);

        // Ajouter l'animal au zoo
        myZoo.addAnimal(lion);

        // Afficher les informations du zoo
        myZoo.displayZooInfo();
    }
}
